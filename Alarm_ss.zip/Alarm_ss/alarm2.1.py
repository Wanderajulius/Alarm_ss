import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
import time
import threading
import sqlite3
import pyttsx3
from datetime import datetime
from hashlib import sha256  # For password hashing

# Initialize SQLite database
conn = sqlite3.connect("timetable.db")
cursor = conn.cursor()

# Create tables if they don't exist
cursor.execute('''
CREATE TABLE IF NOT EXISTS timetable (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    day TEXT NOT NULL,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    activity TEXT NOT NULL
)
''')
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
)
''')
conn.commit()

# Function to hash passwords
def hash_password(password):
    return sha256(password.encode()).hexdigest()

# Add a default admin user if none exists
cursor.execute("SELECT COUNT(*) FROM users")
if cursor.fetchone()[0] == 0:
    cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", 
                   ("admin", hash_password("admin123")))
    conn.commit()

# Timetable initialization
def load_timetable():
    global timetable
    timetable = {day: [] for day in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]}
    cursor.execute("SELECT day, date, time, activity FROM timetable")
    for day, date, time_, activity in cursor.fetchall():
        timetable[day].append((activity, time_, date))

load_timetable()

# Text-to-speech function
def speak(text):
    try:
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()
    except Exception as e:
        print(f"Text-to-speech error: {e}")

# Stop flag for the alarm loop
stop_alarm = False

# Alarm function
def alarm_check():
    global stop_alarm
    while not stop_alarm:
        current_time = time.strftime("%I:%M %p")
        current_day = time.strftime("%A")
        current_date = datetime.now().strftime("%Y-%m-%d")
        
        for activity, alarm_time, alarm_date in timetable.get(current_day, []):
            if stop_alarm:
                break
            if alarm_time == current_time and alarm_date == current_date:
                alarm_display.config(state="normal")
                alarm_display.delete(1.0, tk.END)
                alarm_display.insert(tk.END, f"Current Activity: {activity}\nScheduled Time: {alarm_time}\n")
                alarm_display.config(state="disabled")
                
                while not stop_alarm:
                    speak(f"Please Julius, it's time to {activity}")
                    time.sleep(5)
                break
        time.sleep(1)

def start_alarm_thread():
    global stop_alarm
    stop_alarm = False
    alarm_thread = threading.Thread(target=alarm_check, daemon=True)
    alarm_thread.start()

def stop_alarm_thread():
    global stop_alarm
    stop_alarm = True
    alarm_display.config(state="normal")
    alarm_display.delete(1.0, tk.END)
    alarm_display.insert(tk.END, "Alarm Stopped.\n")
    alarm_display.config(state="disabled")

# Add activity
def add_activity():
    day = day_combobox.get()
    time_ = time_combobox.get()
    activity = activity_entry.get()
    date_ = date_picker.get_date().strftime("%Y-%m-%d")

    if not day or not time_ or not activity or not date_:
        messagebox.showerror("Input Error", "All fields must be filled!")
        return

    cursor.execute("INSERT INTO timetable (day, date, time, activity) VALUES (?, ?, ?, ?)", (day, date_, time_, activity))
    conn.commit()

    timetable[day].append((activity, time_, date_))
    update_timetable_display()
    day_combobox.set("")
    time_combobox.set("")
    activity_entry.delete(0, tk.END)

def update_timetable_display():
    display_text = ""
    for day, activities in timetable.items():
        display_text += f"{day}:\n"
        for activity, time_, date_ in activities:
            display_text += f"  - {activity} on {date_} at {time_}\n"
        display_text += "\n"
    timetable_display.config(state="normal")
    timetable_display.delete(1.0, tk.END)
    timetable_display.insert(tk.END, display_text)
    timetable_display.config(state="disabled")

# Login function
def login():
    username = username_entry.get()
    password = password_entry.get()
    hashed_password = hash_password(password)
    
    cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, hashed_password))
    user = cursor.fetchone()
    
    if user:
        login_frame.pack_forget()
        main_frame.pack(fill="both", expand=True)
    else:
        messagebox.showerror("Login Failed", "Invalid username or password!")

# GUI setup
root = tk.Tk()
root.title("Timetable Alarm System")
root.geometry("300x400")  # Initial size for the login window
root.resizable(False, False)  # Disable resizing for both windows

# Login Frame
login_frame = tk.Frame(root)
login_frame.pack(fill="both", expand=True)

tk.Label(login_frame, text="Login", font=("Arial", 20)).pack(pady=20)
tk.Label(login_frame, text="Username:").pack(pady=5)
username_entry = tk.Entry(login_frame)
username_entry.pack()
tk.Label(login_frame, text="Password:").pack(pady=5)
password_entry = tk.Entry(login_frame, show="*")
password_entry.pack()

login_button = tk.Button(login_frame, text="Login", command=lambda: login())
login_button.pack(pady=10)

# Main Frame
main_frame = tk.Frame(root)

tk.Label(main_frame, text="Day:").pack(pady=5)
day_combobox = ttk.Combobox(main_frame, values=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])
day_combobox.pack()

tk.Label(main_frame, text="Date (Select from calendar):").pack(pady=5)
date_picker = DateEntry(main_frame, date_pattern="yyyy-mm-dd", width=12, background='darkblue', foreground='white', borderwidth=2)
date_picker.pack()

tk.Label(main_frame, text="Time (Select from dropdown):").pack(pady=5)
time_options = [f"{hour:02}:00 AM" for hour in range(1, 12)] + ["12:00 PM"] + \
               [f"{hour:02}:00 PM" for hour in range(1, 12)]
time_combobox = ttk.Combobox(main_frame, values=time_options)
time_combobox.pack()

tk.Label(main_frame, text="Activity:").pack(pady=5)
activity_entry = tk.Entry(main_frame)
activity_entry.pack()

add_button = tk.Button(main_frame, text="Add Activity", command=add_activity)
add_button.pack(pady=10)

tk.Label(main_frame, text="Timetable:").pack(pady=5)
timetable_display = tk.Text(main_frame, height=15, state="disabled", bg="lightblue")
timetable_display.pack()

tk.Label(main_frame, text="Current Alarm:").pack(pady=5)
alarm_display = tk.Text(main_frame, height=3, state="disabled", bg="lightyellow")
alarm_display.pack()

start_button = tk.Button(main_frame, text="Start Alarm", command=start_alarm_thread, bg="green", fg="white")
start_button.pack(pady=5)

stop_button = tk.Button(main_frame, text="Stop Alarm", command=stop_alarm_thread, bg="red", fg="white")
stop_button.pack(pady=5)

# Update timetable display
update_timetable_display()

# Login function with dynamic window resizing
def login():
    username = username_entry.get()
    password = password_entry.get()
    hashed_password = hash_password(password)
    
    cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, hashed_password))
    user = cursor.fetchone()
    
    if user:
        login_frame.pack_forget()
        root.geometry("800x700")  # Resize for the main alarm page
        main_frame.pack(fill="both", expand=True)
    else:
        messagebox.showerror("Login Failed", "Invalid username or password!")

# Run the application
root.mainloop()
conn.close()
